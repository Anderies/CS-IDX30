= FREN (500) + TLKM (500) + BRIS (500) + ANTM (449) + BJTM (414)
= 500 + 500 + 500 + 449 + 414 records
= 2.363